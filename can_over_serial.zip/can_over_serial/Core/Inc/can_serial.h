
#ifndef __CAN_SERIAL_H_
#define __CAN_SERIAL_H_


#define SOF    0xAA
#define EOF    0xBB

typedef enum
{
	state_start,
	state_time_stamp,
	state_dlc,
	state_arbitration_id,
	state_payload,
	state_end,
}can_uart_state_t;

typedef struct
{
	uint8_t sof;
	uint32_t timestamp;
	uint8_t dlc;
	uint32_t arbitration_id;
	uint8_t payload[8];
	uint8_t eof;
} __attribute__((packed)) CanSerialPacket_t;

extern CanSerialPacket_t can_packet;

void process_serial_bus(uint8_t *buff);
void send_over_serial(CanSerialPacket_t *can_packet);
void send_over_can(CanSerialPacket_t *can_packet);




#endif /*__CAN_SERIAL_H_*/
