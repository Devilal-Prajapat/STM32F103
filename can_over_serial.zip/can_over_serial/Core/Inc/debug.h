
#ifndef __DEBUG_H_
#define __DEBUG_H_

#define DBG_LOG(...)    dbg_printf(__VA_ARGS__)

void dbg_printf(char *format, ...);
#endif /*__DEBUG_H_*/
