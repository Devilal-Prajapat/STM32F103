/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "can.h"
#include "iwdg.h"
#include "tim.h"
#include "usart.h"
#include "usb_device.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "debug.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include "usbd_cdc_if.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
#define MAJOR    1
#define MINOR    0
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
CAN_TxHeaderTypeDef can_tx_header;
CAN_RxHeaderTypeDef can_rx_header;
uint8_t can_rx_buffer[19];
extern uint8_t rxdata;
/* USER CODE END PV */

int _write(int file, char *ptr, int len)
{
	CDC_Transmit_FS(ptr, len);
	return len;
}

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void Can_Tx(void);
void CAN_FilterConfig(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_CAN_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
 // MX_IWDG_Init();
  MX_TIM3_Init();
//  MX_USB_DEVICE_Init();
  /* USER CODE BEGIN 2 */
  DBG_LOG("app ver: v%d.%d", MAJOR, MINOR);

  HAL_CAN_Start(&hcan);
  HAL_CAN_ActivateNotification(&hcan, CAN_IT_RX_FIFO1_MSG_PENDING);

  HAL_UART_Receive_IT(CAN_UART, &rxdata, 1);
  /* USER CODE END 2 */
  Can_Tx();
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
#if 1
	  Can_Tx();
	  if((HAL_GetTick() % 1000) == 0)
	  {
		  //Can_Tx();
	  }
#else
	  memset(can_rx_buffer,0x00,19);
	process_serial_bus(can_rx_buffer);

	memset(&can_packet, 0x00, sizeof(can_packet));
	can_packet.arbitration_id = 0x12345;
	can_packet.sof = SOF;
	can_packet.timestamp = can_rx_header.Timestamp;
	can_packet.dlc = can_rx_header.DLC;
	memcpy(&can_packet.payload[0],"12345678",8);
	can_packet.eof = EOF;
	send_over_serial(&can_packet);
	DBG_LOG((char *)&can_packet);
#endif

  }
  DBG_LOG("app ver: v%d.%d", MAJOR, MINOR);
  HAL_Delay(100);
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USB;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLL;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void CAN_FilterConfig(void)
 {
 	CAN_FilterTypeDef filter_config;
 	filter_config.FilterActivation = ENABLE;
 	filter_config.FilterBank = 0;
 	filter_config.FilterIdHigh = 0x00;
 	filter_config.FilterIdLow = 0x00;
 	filter_config.FilterMaskIdHigh = 0x00;
 	filter_config.FilterMaskIdLow = 0x00;
 	filter_config.FilterMode = CAN_FILTERMODE_IDMASK; // ID mask or id list
 	filter_config.FilterScale = CAN_FILTERSCALE_32BIT;
 	filter_config.FilterFIFOAssignment = CAN_RX_FIFO0;
 	if(HAL_CAN_ConfigFilter(&hcan,&filter_config)!=HAL_OK)
 	{
 		Error_Handler();
 	}

 }

void Can_Tx(void)
{
	CAN_TxHeaderTypeDef Tx_HeaderInit;
	uint8_t msg[] = {'N', 'A','G', 'A','R', 'R','O'};
	uint32_t txMailBox;
	static uint8_t count = 0;
	msg[7] = count++;

	Tx_HeaderInit.DLC = 8;
	Tx_HeaderInit.ExtId = 0x123456;
	Tx_HeaderInit.StdId  = 0;
	Tx_HeaderInit.RTR = CAN_RTR_DATA;
	Tx_HeaderInit.IDE = CAN_ID_EXT;
	DBG_LOG("Transmitting\r\n");
	HAL_CAN_AddTxMessage(&hcan, &Tx_HeaderInit,&msg[0], &txMailBox);
	//while(HAL_CAN_IsTxMessagePending(&hcan, txMailBox));
	DBG_LOG("Send OK\r\n");
	HAL_Delay(1000);
}


void dbg_printf(char *format, ...)
{
	char buff[128];
	uint8_t len;
	va_list list;
	va_start(list, format);
	len = vsprintf(buff,format, list);
	if(len != 0)
#if 1
		HAL_UART_Transmit(DBG_UART, (uint8_t *)buff, (uint16_t)len, 100);
#else
		CDC_Transmit_FS(buff, len);
#endif
	va_end(list);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
	DBG_LOG("Error Handler");
	HAL_Delay(1000);
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
