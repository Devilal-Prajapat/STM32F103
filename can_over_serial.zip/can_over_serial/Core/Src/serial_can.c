/*
 * serial_can.c
 *
 *  Created on: 18-Jan-2023
 *      Author: devilalprajapat
 */
#include <string.h>
#include "debug.h"
#include "usart.h"
#include "can_serial.h"
#include "can.h"

#if 0
static uint16_t receive_chunk(uint8_t *buff, uint16_t max_len)
{
	int16_t ret;
	uint16_t index = 0;
	uint16_t data_len;
	do
	{
		ret = HAL_UART_Receive(CAN_UART, &buff[index], 1, 100);
		if(ret != HAL_OK)
		{
			break;
		}

		if(buff[index++] != SOF)
		{
			//
			ret = HAL_ERROR;
		}

		ret = HAL_UART_Receive(CAN_UART, &buff[index], 4, HAL_MAX_DELAY);
		if(ret != HAL_OK)
		{
			break;
		}
		index += 4;
		ret = HAL_UART_Receive(CAN_UART, &buff[index], 1, HAL_MAX_DELAY);
		if(ret != HAL_OK)
		{
			break;
		}

		data_len = (buff[index]);  // dlc
		index += 1;
		ret = HAL_UART_Receive(CAN_UART, &buff[index], 4, HAL_MAX_DELAY);

		if(ret != HAL_OK)
		{
			break;
		}

		index += 4;
		if(data_len != 0)
		{
			ret = HAL_UART_Receive(CAN_UART, &buff[index], data_len , HAL_MAX_DELAY);

			if(ret != HAL_OK)
			{
				break;
			}
		}

		index += data_len;

		//EOF
		ret = HAL_UART_Receive(CAN_UART, &buff[index], 1 , HAL_MAX_DELAY);
		if(ret != HAL_OK)
		{
			break;
		}
		if(buff[index++] != EOF)
		{
			ret = HAL_ERROR;
		}
	}while(0);

	 if( ret != HAL_OK )
	  {
	    //clear the index if error
	    index = 0u;
	  }

	  if( max_len < index )
	  {
	    DBG_LOG( "Received more Expected = %d, Received = %d\r\n", max_len, index );
	    index = 0u;
	  }
	  return index;
}

void process_serial_bus(uint8_t *buff)
{
	uint16_t len = receive_chunk(buff, 19);
	if(len != 0)
	{
		CanSerialPacket_t *pkt = (CanSerialPacket_t *)buff;
		send_over_can(pkt);
		HAL_UART_Transmit(DBG_UART, (uint8_t *)pkt, (11 + pkt->dlc) , 100);
		DBG_LOG("\r\n can_rx_buff : ");
		HAL_UART_Transmit(DBG_UART, (uint8_t *)buff, len , 100);
	}
}
#endif

void process_serial_bus(uint8_t *buff)
{
	CanSerialPacket_t *pkt = (CanSerialPacket_t *)buff;
	if(pkt->sof == 0xAA && pkt->eof == 0xBB && pkt->dlc <=8)
	{
		send_over_can(pkt);
		HAL_UART_Transmit(DBG_UART, (uint8_t *)pkt, (11 + pkt->dlc) , 100);
	}
}

void send_over_serial(CanSerialPacket_t *can_packet)
{
	uint8_t len = can_packet->dlc + 11;
	HAL_UART_Transmit(CAN_UART, (uint8_t *)can_packet, len , 100);
	HAL_UART_Transmit(DBG_UART, (uint8_t *)can_packet, len , 100);
}

void send_over_can(CanSerialPacket_t *can_packet)
{
	//DBG_LOG((char *)can_packet);
	CAN_TxHeaderTypeDef Tx_HeaderInit;
	uint8_t msg[8] = {0};
	uint32_t txMailBox;

	Tx_HeaderInit.DLC = can_packet->dlc;
	Tx_HeaderInit.ExtId = 0x123456;
	Tx_HeaderInit.StdId  = 0;
	Tx_HeaderInit.RTR = CAN_RTR_DATA;
	Tx_HeaderInit.IDE = CAN_ID_EXT;
	DBG_LOG("Transmitting\r\n");
	memcpy(&msg[0], can_packet->payload, can_packet->dlc);
	HAL_CAN_AddTxMessage(&hcan, &Tx_HeaderInit, &msg[0], &txMailBox);
	while(HAL_CAN_IsTxMessagePending(&hcan, txMailBox));
	DBG_LOG("Send OK\r\n");
}
