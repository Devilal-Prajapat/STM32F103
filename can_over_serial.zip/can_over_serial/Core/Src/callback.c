/*
 * callback.c
 *
 *  Created on: Jan 17, 2023
 *      Author: devilalprajapat
 */

#include "can.h"
#include "tim.h"
#include "iwdg.h"
#include "usart.h"
#include "gpio.h"
#include "debug.h"
#include "can_serial.h"
#include "string.h"

CanSerialPacket_t can_packet;
can_uart_state_t can_uart_state;

uint8_t rxbuff[128];
uint8_t rx_count;
uint8_t rxdata;


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance == CAN_UART->Instance)
	{
		rxbuff[rx_count++] = rxdata;
		HAL_UART_Receive_IT(CAN_UART, &rxdata, 1);
		HAL_TIM_Base_Start_IT(&htim3);
	}
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance == TIM3)
	{
		HAL_TIM_Base_Stop_IT(&htim3);
		CanSerialPacket_t *pkt = (CanSerialPacket_t *)rxbuff;
		if(pkt->sof == 0xAA && pkt->eof == 0xBB && pkt->dlc <=8)
		{
			DBG_LOG("\r\n------ UART_RX--------\r\n");
			send_over_can(pkt);
			HAL_UART_Transmit(DBG_UART, (uint8_t *)pkt, (11 + pkt->dlc) , 100);
#if 0
			DBG_LOG("\r\n can_rx_buff : ");
			HAL_UART_Transmit(DBG_UART, (uint8_t *)rxbuff, rx_count , 100);
#endif
		}
		memset(rxbuff, 0x00, 128);
		rx_count = 0;
	}

}

void HAL_CAN_RxFifo1MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
	DBG_LOG("\r\n------ CAN_RX1---------\r\n");
	if(hcan->Instance == CAN1)
	{
		CAN_RxHeaderTypeDef can_rx_header;
	    uint8_t can_rx_buff[8];
		HAL_CAN_GetRxMessage(hcan,CAN_RX_FIFO1, &can_rx_header, &can_rx_buff[0]);

		memset(&can_packet, 0x00, sizeof(can_packet));
		if(can_rx_header.IDE == CAN_ID_EXT)
		{
			can_packet.arbitration_id = can_rx_header.ExtId;
		}
		else
		{
			can_packet.arbitration_id = can_rx_header.StdId;
		}
		can_packet.sof = SOF;
		can_packet.timestamp = can_rx_header.Timestamp;
		can_packet.dlc = can_rx_header.DLC;
		memcpy(&can_packet.payload,can_rx_buff, can_packet.dlc);
		can_packet.eof = EOF;
		send_over_serial(&can_packet);
	}
}


